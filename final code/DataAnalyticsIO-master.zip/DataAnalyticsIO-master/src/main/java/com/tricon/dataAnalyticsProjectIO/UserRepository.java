package com.tricon.dataAnalyticsProjectIO;

import java.util.Map;

import org.springframework.data.redis.core.RedisHash;
@RedisHash("User")
public interface UserRepository {
	Map<String, User> findAll();
	
	

}

