package com.tricon.dataAnalyticsProjectIO;

/**
 * 
 */

import redis.clients.jedis.Jedis; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;


@RestController
public class controller {
	

	
	
	public String validate(String key)
	{
		Jedis jedis = new Jedis("172.16.17.187");
		System.out.println(jedis.get(key));
		jedis.close();
		return jedis.get(key);
	}
	
	
	

    @Autowired
	KafkaTemplate<String, JsonNode> kafkaJsonTemplate;
	
	String TOPIC_NAME = "client";//topic name of kafka
	
	
	@RequestMapping(value="/shubham", method=RequestMethod.POST)
	
		
	public ResponseEntity<String> eventCapture(@RequestBody JsonNode jobj){
		if(validate(jobj.get("id").asText()) != null) {
		kafkaJsonTemplate.send(TOPIC_NAME, jobj);
		System.out.println(jobj);
		return new ResponseEntity<>("successfully added", HttpStatus.CREATED);
		}
		
		else
		{
			return new ResponseEntity<>("Cannot be added", HttpStatus.CREATED);
		}
		
	}
	
	
}