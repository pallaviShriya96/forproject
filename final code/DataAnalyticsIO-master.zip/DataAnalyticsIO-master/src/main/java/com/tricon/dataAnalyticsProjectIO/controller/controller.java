/**
 * 
 */
package com.tricon.dataAnalyticsProjectIO.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

@RestController
public class controller {
	
	@Autowired
	KafkaTemplate<String, JsonNode> kafkaJsonTemplate;
	
	//String TOPIC_NAME = "items-topic";//topic name of kafka
	
	@RequestMapping(value="/shubham", method=RequestMethod.POST)
	public ResponseEntity<String> eventCapture(@RequestBody JsonNode jobj){
		String url=jobj.get("url").asText();
		String TOPIC_NAME=url.substring(0, url.lastIndexOf("."));
		kafkaJsonTemplate.send(TOPIC_NAME, jobj);
		System.out.println(jobj);
		return new ResponseEntity<String>("successfully added", HttpStatus.CREATED);
	}
	
}