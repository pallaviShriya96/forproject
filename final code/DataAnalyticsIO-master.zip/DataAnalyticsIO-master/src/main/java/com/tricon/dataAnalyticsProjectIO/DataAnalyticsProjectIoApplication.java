package com.tricon.dataAnalyticsProjectIO;

import redis.clients.jedis.Jedis; 

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class DataAnalyticsProjectIoApplication {

	
	
	
	public static void main(String[] args) {
		SpringApplication.run(DataAnalyticsProjectIoApplication.class, args);
		Jedis jedis = new Jedis("172.16.17.187");
		System.out.println("Connection to server sucessfully"); 
	      //check whether server is running or not 
	      System.out.println("Server is running: "+jedis.ping()); 
	      jedis.close();
	}
	
}
