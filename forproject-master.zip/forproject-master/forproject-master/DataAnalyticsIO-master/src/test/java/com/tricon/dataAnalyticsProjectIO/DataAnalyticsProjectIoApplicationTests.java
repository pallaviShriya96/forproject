package com.tricon.dataAnalyticsProjectIO;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.test.context.junit4.SpringRunner;
@SpringBootApplication
@RunWith(SpringRunner.class)
@SpringBootTest
public class DataAnalyticsProjectIoApplicationTests {

	@Test
	public void contextLoads() {
	}
	
	@Bean
	JedisConnectionFactory jeddisconnectionfactory() {
		return new JedisConnectionFactory();
		
	}

}
