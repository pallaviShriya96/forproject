package com.tricon.dataAnalyticsProjectIO;



import java.io.Serializable;
public class User implements Serializable {
	

	private String Tenantid;

	public String getTenantid() {
		return Tenantid;
	}

	public void setTenantid(String tenantid) {
		Tenantid = tenantid;
	}

	
	


}
