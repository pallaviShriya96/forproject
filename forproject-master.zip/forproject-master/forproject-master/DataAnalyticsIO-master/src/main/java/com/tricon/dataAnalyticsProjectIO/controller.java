package com.tricon.dataAnalyticsProjectIO;

/**
 * 
 */


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;


@RestController
public class controller {
	
	private UserRepository userRepo;
	
	public controller(UserRepository userRepo) {
		this.userRepo = userRepo;
	}
	@GetMapping("/all")
	public Map<String,User> update(){
		return userRepo.findAll();
		
	}
	
	@GetMapping("/add/{id}/{name}")
	public User add(@PathVariable("id") final String id,
			@PathVariable("name") final String name) {
		userRepo.save(new User(id,name));
				return user ;
		
		
	}
	
	@Autowired
	KafkaTemplate<String, JsonNode> kafkaJsonTemplate;
	
	String TOPIC_NAME = "client";//topic name of kafka
	
	
	@RequestMapping(value="/shubham", method=RequestMethod.POST)
	
	public ResponseEntity<String> eventCapture(@RequestBody JsonNode jobj){
		
		kafkaJsonTemplate.send(TOPIC_NAME, jobj);
		System.out.println(jobj);
		return new ResponseEntity<>("successfully added", HttpStatus.CREATED);
	}
	
	
}