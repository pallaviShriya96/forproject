package com.tricon.dataAnalyticsProjectIO;


import java.util.Map;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class UserRepositoryimpl implements UserRepository{
	RedisTemplate<String,User> redisTemplate;
	HashOperations hashOperations;
	public UserRepositoryimpl(RedisTemplate<String, User> redisTemplate) {
		super();
		this.redisTemplate = redisTemplate;
		 
		 hashOperations=redisTemplate.opsForHash();
	}
	
	
	

	@Override
	public Map<String, User> findAll() {
		return hashOperations.entries("USER");
		
		
	}
	

}
