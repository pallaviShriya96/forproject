package com.tricon.dataAnalyticsProjectIO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataAnalyticsProjectIoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataAnalyticsProjectIoApplication.class, args);
	}

}
