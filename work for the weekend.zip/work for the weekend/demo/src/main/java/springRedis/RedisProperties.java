package springRedis;

public class RedisProperties {

}
