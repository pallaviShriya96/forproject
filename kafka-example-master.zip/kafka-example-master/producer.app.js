
const kafka = require('kafka-node');
const config = require('./config');
var express =require('express');
var bodyParser= require('body-parser');

var app= express();
app.use(bodyParser.json());
app.listen(3001,function(){
    console.log('strated on port:3001');
})

try {
  const Producer = kafka.Producer;
  const client = new kafka.Client(config.kafka_server);
  const producer = new Producer(client);
  const kafka_topic = 'test';
  console.log(kafka_topic);
  
  var temp;
 app.post("/",function(req,res,next){
    
    let payloads = [
      {
        topic: kafka_topic,
        messages: req.body
      }
    ];
    // console.log(req.body);
    producer.on('ready', async function() {
      let push_status = producer.send(payloads, (err, data) => {
        if (err) {
          console.log('[kafka-producer -> '+kafka_topic+']: broker update failed');
        } else {
          console.log('here');
          console.log('[kafka-producer -> '+req.body+']: broker update success');
        }
      });
    });
    
    // console.log(temp);
    res.send('successfully added');
  });

  console.log(temp);

  // let payloads = [
  //   {
  //     topic: kafka_topic,
  //     messages: temp
  //   }
  // ];

  // producer.on('ready', async function() {
  //   let push_status = producer.send(payloads, (err, data) => {
  //     if (err) {
  //       console.log('[kafka-producer -> '+kafka_topic+']: broker update failed');
  //     } else {
  //       console.log('[kafka-producer -> '+temp+']: broker update success');
  //     }
  //   });
  // });

  producer.on('error', function(err) {
    console.log(err);
    console.log('[kafka-producer -> '+kafka_topic+']: connection errored');
    throw err;
  });
}
catch(e) {
  console.log(e);
}
