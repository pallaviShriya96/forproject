module.exports = {
  kafka_topic: 'test',
  kafka_server: 'localhost:2181',
};
